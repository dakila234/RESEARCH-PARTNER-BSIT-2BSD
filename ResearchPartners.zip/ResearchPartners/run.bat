@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -d out src\researchpartners\*.java && java -cp out researchpartners.Launcher
pause
