# Research Partners

A group chat for student research teams. Ideas shared in a normal chat scroll away, and "we agreed on the
survey" is easy to dispute later. Research Partners adds two shared tools next to the chat:

1. **Idea cards with categories** - pin an idea as a *Hypothesis*, *Method*, *Source* or *Question* card. Cards sit on a shared board in four lists; the author can remove a card.
2. **Group decisions with recorded votes** - put any idea (or any question) to a vote. The record shows **who voted for what**, votes can be changed until the owner closes the vote, and closing records the outcome (winner, tie, or no votes).

Every person's name has its own colour (chat, online list, idea lists, vote records), so it is easy to see who said or voted what.

Built with Java Swing (JFrame) in Apache NetBeans. Plain TCP sockets, no external libraries.

## Concept Proposal

| | |
|---|---|
| **Audience** | Student research teams (thesis or class research groups) |
| **Problem** | Ideas get lost in a busy chat, and nobody can prove who agreed to which decision |
| **Feature 1** | Idea cards with categories (Hypothesis / Method / Source / Question) on a shared board; "Decide" turns a card into a vote |
| **Feature 2** | Group decisions with recorded votes (names per option, changeable until closed, recorded outcome) |
| **Sample screens** | _Add screenshots here: join screen, Idea Board, Decisions, chat_ |
| **Instructor approval** | _Name / date:_ |

## How to run (NetBeans)

1. Unzip `ResearchPartners.zip`.
2. NetBeans: **File > Open Project...** and pick the `ResearchPartners` folder.
3. Right-click the project > **Run** (main class is `researchpartners.Launcher`).
4. In the launcher: **Start server** on the host computer, then click **Start server** inside the Host Console. It must say "Running on port 5070".
5. Click **Open client** for each user. On a second computer, enter the host's IP address (shown in the Host Console) and port `5070`.

If NetBeans cannot open it as a project: create a new *Java with Ant > Java Application*, then copy the
`src/researchpartners` files into it. Or run `run.bat` (Windows) / `run.sh` (Linux/Mac) with a JDK installed.

Requires JDK 11 or newer. Both computers must be on the same network and the server's firewall must allow the port.

## Commands

| Command | What it does |
|---|---|
| `/list` | show who is online |
| `/msg <nick> <text>` | private message |
| `/quit` | leave the chat |
| `/idea Category \| text` | pin an idea card (Hypothesis, Method, Source, Question) |
| `/decide Question \| option \| option ...` | open a vote (2 to 5 options) |
| `/vote <decision #> <option #>` | vote, or change your vote |
| `/close <decision #>` | close your vote and record the outcome |
| `/delidea <#>` | remove your idea card |
| `/help` | list commands |

## Code overview

| File | Responsibility |
|---|---|
| `Protocol` | message format (`COMMAND\|field\|field`, fields URL-encoded), nickname validation |
| `ChatServer` | accept loop, online users, broadcast |
| `ClientHandler` | one thread per client; reads and handles that client's messages |
| `IdeaBoard`, `Idea` | server-side idea cards (synchronized) |
| `DecisionBoard`, `Decision`, `Result` | server-side decisions, recorded votes and outcome (synchronized) |
| `ClientConnection` | client socket, HELLO handshake, reader thread |
| `ConnectView/Frame` | join screen; connects in a `SwingWorker` so the window never freezes |
| `MainView`, `MainFrame` | main screen: menu bar, tabs (Idea Board, Decisions) on top, chat underneath; moves incoming messages onto the Swing thread |
| `IdeaBoardPage` | feature 1: one list per category, add / decide / remove |
| `DecisionsPage`, `Names` | feature 2: decision list, options with voter names, vote and close buttons |
| `ChatPanel` | team chat: log with a colour for every person's name, online list (same colours) and input line |
| `ServerView/Frame`, `Launcher` | host console and start window |
| `Theme` | normal system look and feel, plus the colours: one name colour per person, a colour per idea category, pale tinted panels, coloured titles |

Message path: user types -> `MainView` -> `ClientConnection.send` -> socket -> `ClientHandler.handle`
-> `IdeaBoard` / `DecisionBoard` (if a feature action) -> `ChatServer.broadcast` -> every `ClientHandler.send`
-> each client's reader thread -> `SwingUtilities.invokeLater` -> GUI update.

## Test evidence

See [TEST_EVIDENCE.md](TEST_EVIDENCE.md) for the automated test results (Part A) and the two-computer manual test sheet (Part B).

## Contribution log

| Partner | Work done | Evidence (commits, screenshots) |
|---|---|---|
| Partner 1 | | |
| Partner 2 | | |

## Credits and AI assistance

- Java SE / Swing (JDK standard library only).
- Code was generated with assistance from Claude (Anthropic) and then reviewed by the team.
  _Edit this line to describe what you changed or wrote yourselves._
