package researchpartners;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Automated protocol test: starts a ChatServer on port 5999 and connects simulated clients.
 * Run it (Run File) to reproduce the results in TEST_EVIDENCE.md.
 */
public class SmokeTest {

    static class C implements ClientConnection.Listener {
        final String name;
        final ClientConnection conn = new ClientConnection();
        final BlockingQueue<String> got = new LinkedBlockingQueue<>();

        C(String n) { name = n; }

        public void onMessage(String[] p) { got.add(String.join("|", p)); }
        public void onClosed() { got.add("CLOSED"); }

        boolean has(String text, int ms) throws Exception {
            long end = System.currentTimeMillis() + ms;
            while (true) {
                for (String s : got) {
                    if (s.contains(text)) {
                        return true;
                    }
                }
                if (System.currentTimeMillis() >= end) {
                    return false;
                }
                Thread.sleep(50);
            }
        }

        int count(String prefix) {
            int n = 0;
            for (String s : got) {
                if (s.startsWith(prefix)) {
                    n++;
                }
            }
            return n;
        }
    }

    static int failures = 0;

    static void check(String what, boolean ok) {
        if (!ok) {
            failures++;
        }
        System.out.println((ok ? "PASS " : "FAIL ") + what);
    }

    public static void main(String[] a) throws Exception {
        ChatServer s = new ChatServer(new ChatServer.Listener() {
            public void onLog(String m) { }
            public void onUserCountChanged(int c) { }
        });
        s.start(5999);
        C[] c = {new C("Ana"), new C("Ben"), new C("Cy")};
        for (C x : c) {
            x.conn.connect("localhost", 5999, x.name);
            x.conn.startReading(x);
        }

        ClientConnection dup = new ClientConnection();
        try { dup.connect("localhost", 5999, "ana"); check("duplicate nickname rejected", false); }
        catch (Exception e) { check("duplicate nickname rejected: " + e.getMessage(), true); }
        ClientConnection bad = new ClientConnection();
        try { bad.connect("localhost", 5999, "a|b"); check("invalid nickname rejected", false); }
        catch (Exception e) { check("invalid nickname rejected: " + e.getMessage(), true); }

        Thread.sleep(300);
        c[0].conn.send(Protocol.build("MSG", "method | survey?"));
        Thread.sleep(300);
        for (C x : c) {
            check(x.name + " got the group message exactly once", x.count("MSG|") == 1);
        }
        check("the | character survives in text", c[1].has("method | survey?", 100));
        check("online list shows 3 users", c[2].has("USERS|Ana|Ben|Cy", 300));

        c[0].conn.send(Protocol.build("PM", "ben", "psst"));
        Thread.sleep(200);
        check("private message reaches Ben and Ana, not Cy",
                c[1].count("PM|") == 1 && c[0].count("PM|") == 1 && c[2].count("PM|") == 0);

        // feature 1: idea cards with categories
        c[0].conn.send(Protocol.build("I_ADD", "Hypothesis", "Sleep affects quiz scores"));
        Thread.sleep(250);
        for (C x : c) {
            check(x.name + " sees the idea card", x.has("I_SET|1|Ana|Hypothesis|Sleep affects quiz scores|ACTIVE", 300));
        }
        c[1].conn.send(Protocol.build("I_ADD", "Banana", "wrong category"));
        check("unknown category refused", c[1].has("ERR|Category must be one of", 300));
        c[1].conn.send(Protocol.build("I_ADD", "method", "   "));
        check("empty idea refused", c[1].has("ERR|An idea card cannot be empty", 300));
        c[1].conn.send(Protocol.build("I_ADD", "method", "Online survey"));
        Thread.sleep(200);
        check("category matched ignoring case", c[2].has("I_SET|2|Ben|Method|Online survey", 300));
        c[1].conn.send(Protocol.build("I_DEL", "1"));
        check("only the author can remove a card", c[1].has("ERR|Only Ana can remove", 300));

        // feature 2: group decisions with recorded votes
        c[0].conn.send(Protocol.build("D_ADD", "Adopt idea 2?", "2", "Adopt", "Drop"));
        Thread.sleep(250);
        for (C x : c) {
            check(x.name + " sees the decision linked to idea 2", x.has("D_SET|1|Ana|Adopt idea 2?|2|OPEN||Adopt||Drop|", 300));
        }
        c[0].conn.send(Protocol.build("D_ADD", "Linked to nothing", "99", "Yes", "No"));
        check("decision about a missing idea refused", c[0].has("ERR|Idea #99 does not exist", 300));
        c[0].conn.send(Protocol.build("D_ADD", "One option only", "0", "Yes"));
        check("decision with one option refused", c[0].has("ERR|A decision needs 2 to 5", 300));

        c[1].conn.send(Protocol.build("D_VOTE", "1", "0"));
        c[2].conn.send(Protocol.build("D_VOTE", "1", "1"));
        Thread.sleep(300);
        check("votes are recorded by name (Ben for Adopt, Cy for Drop)",
                c[0].has("|OPEN||Adopt|Ben|Drop|Cy", 300));
        c[2].conn.send(Protocol.build("D_VOTE", "1", "0"));
        Thread.sleep(250);
        check("changing a vote moves the name", c[0].has("|OPEN||Adopt|Ben,Cy|Drop|", 300));
        c[2].conn.send(Protocol.build("D_VOTE", "1", "7"));
        check("vote for a missing option refused", c[2].has("ERR|That option does not exist", 300));
        c[1].conn.send(Protocol.build("D_CLOSE", "1"));
        check("non-owner cannot close", c[1].has("ERR|Only Ana can close", 300));
        c[0].conn.send(Protocol.build("D_CLOSE", "1"));
        Thread.sleep(250);
        check("owner closes: outcome recorded as Adopt", c[2].has("|DECIDED|Adopt|Adopt|Ben,Cy|Drop|", 300));
        c[1].conn.send(Protocol.build("D_VOTE", "1", "1"));
        check("voting after close refused", c[1].has("ERR|Decision #1 is already closed", 300));

        c[0].conn.send(Protocol.build("D_ADD", "Tie test", "0", "A", "B"));
        Thread.sleep(200);
        c[1].conn.send(Protocol.build("D_VOTE", "2", "0"));
        c[2].conn.send(Protocol.build("D_VOTE", "2", "1"));
        Thread.sleep(200);
        c[0].conn.send(Protocol.build("D_CLOSE", "2"));
        check("tie is recorded as a tie", c[1].has("|DECIDED|Tie: A / B|", 400));

        c[0].conn.send(Protocol.build("D_ADD", "Owner leaves", "0", "A", "B"));
        Thread.sleep(200);
        c[0].conn.disconnect();
        Thread.sleep(400);
        c[1].conn.send(Protocol.build("D_CLOSE", "3"));
        Thread.sleep(250);
        check("anyone can close once the owner has left", c[2].has("|DECIDED|No votes|", 400));
        c[1].conn.send(Protocol.build("MSG", "still here"));
        check("chat continues after a disconnect", c[2].has("still here", 300));

        C late = new C("Dee");
        late.conn.connect("localhost", 5999, "Dee");
        late.conn.startReading(late);
        check("late joiner receives ideas and decisions", late.has("I_SET|2|Ben", 400) && late.has("D_SET|1|Ana", 400));

        c[1].conn.send(Protocol.build("I_DEL", "2"));
        Thread.sleep(250);
        check("author removes a card: REMOVED reaches clients", c[2].has("I_SET|2|Ben|Method|Online survey|REMOVED", 300));

        // GUI pages (lightweight components work without a screen)
        javax.swing.SwingUtilities.invokeAndWait(() -> {
            IdeaBoardPage ip = new IdeaBoardPage("Ben", l -> { }, id -> { });
            DecisionsPage dp = new DecisionsPage("Ben", l -> { });
            String[] idea = Protocol.parse(Protocol.build("I_SET", "1", "Ana", "Method", "Survey", "ACTIVE"));
            String[] dec = Protocol.parse(Protocol.build("D_SET", "1", "Ana", "Adopt?", "1", "OPEN", "",
                    "Yes", "Ana,Ben", "No", ""));
            ip.setIdeas(java.util.Collections.singletonList(idea));
            dp.setDecisions(java.util.Collections.singletonList(dec));
            ip.setIdeas(new java.util.ArrayList<>());
            dp.setDecisions(new java.util.ArrayList<>());
        });
        check("Idea Board and Decisions pages build and update", true);

        s.stop();
        System.out.println(failures == 0 ? "ALL PASSED" : failures + " FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
