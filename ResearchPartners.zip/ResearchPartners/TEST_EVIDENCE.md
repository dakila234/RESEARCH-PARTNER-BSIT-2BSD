# Test Evidence - Research Partners

## Part A: Automated test (already run)

`test/researchpartners/SmokeTest.java` starts a real `ChatServer` and connects three simulated clients
(Ana, Ben, Cy) over real sockets, then a fourth (Dee) later. To reproduce: in NetBeans open the file
and choose **Run File** (Shift+F6).

Run date: 2026-11-19, JDK 21, one computer (localhost). Result: **all 33 checks passed.**

| What was tested | Expected | Result |
|---|---|---|
| Join with a nickname already taken / invalid nickname | Rejected with message | PASS |
| Group message from Ana | Ana, Ben and Cy each receive it exactly once | PASS |
| Message containing the `\|` character | Arrives unchanged | PASS |
| Online list and private message | Correct users only | PASS |
| Pin an idea card | All clients see it with its category | PASS |
| Unknown category / empty idea | Refused with error | PASS |
| Category typed in lower case | Matched to the right category | PASS |
| Non-author removes a card | Refused with error | PASS |
| Open a decision linked to an idea | All clients see it | PASS |
| Decision linked to a missing idea / only one option | Refused with error | PASS |
| Ben and Cy vote | Votes recorded by name per option | PASS |
| Cy changes her vote | Her name moves to the new option | PASS |
| Vote for a missing option | Refused with error | PASS |
| Non-owner closes the decision | Refused with error | PASS |
| Owner closes the decision | Outcome recorded for everyone | PASS |
| Vote after the decision is closed | Refused with error | PASS |
| Equal votes, then close | Outcome recorded as a tie | PASS |
| Owner disconnects, another member closes | Allowed; outcome recorded | PASS |
| Chat after a disconnect | Remaining users keep chatting | PASS |
| Late joiner | Receives existing cards and decisions | PASS |
| Author removes a card | REMOVED reaches clients | PASS |
| Idea Board and Decisions pages | Build and update without errors | PASS |

Raw output of the run:

```
PASS duplicate nickname rejected: The nickname 'ana' is already taken.
PASS invalid nickname rejected: Nickname may only contain letters, numbers, '_' and '-'.
PASS Ana got the group message exactly once
PASS Ben got the group message exactly once
PASS Cy got the group message exactly once
PASS the | character survives in text
PASS online list shows 3 users
PASS private message reaches Ben and Ana, not Cy
PASS Ana sees the idea card
PASS Ben sees the idea card
PASS Cy sees the idea card
PASS unknown category refused
PASS empty idea refused
PASS category matched ignoring case
PASS only the author can remove a card
PASS Ana sees the decision linked to idea 2
PASS Ben sees the decision linked to idea 2
PASS Cy sees the decision linked to idea 2
PASS decision about a missing idea refused
PASS decision with one option refused
PASS votes are recorded by name (Ben for Adopt, Cy for Drop)
PASS changing a vote moves the name
PASS vote for a missing option refused
PASS non-owner cannot close
PASS owner closes: outcome recorded as Adopt
PASS voting after close refused
PASS tie is recorded as a tie
PASS anyone can close once the owner has left
PASS chat continues after a disconnect
PASS late joiner receives ideas and decisions
PASS author removes a card: REMOVED reaches clients
PASS Idea Board and Decisions pages build and update
ALL PASSED
```

## Part B: Manual test on two computers (fill in during your demo)

Setup used: Server on Computer ____ (IP ________, port 5070). Clients: ________ on Computer A,
________ and ________ on Computer B. Date tested: ________

| # | Test | Expected | Result (Pass/Fail) | Screenshot |
|---|---|---|---|---|
| 1 | Three clients connect across two computers | All appear in the Online list | | |
| 2 | Duplicate nickname on the join screen | Error message shown | | |
| 3 | Wrong port or server not running | "Could not reach the server" message, window does not freeze | | |
| 4 | Group chat | Each client sees each message once, with sender and time | | |
| 5 | Join and leave | Notice in chat and Online list updates | | |
| 6 | Required commands (list them here) | Each works | | |
| 7 | Pin cards in each category | Cards appear in the right list on every screen | | |
| 8 | Remove your own card | Disappears on every screen | | |
| 9 | Press Decide on a card | A linked vote opens on every screen | | |
| 10 | Vote, change a vote | Voter names move on every screen | | |
| 11 | Owner closes a vote | Outcome recorded and buttons disabled everywhere | | |
| 12 | Close one client window | Others keep working | | |
| 13 | Stop the server while clients are open | Clients show a "lost connection" message and return to the join screen | | |

## Screenshots to attach

1. Join screen
2. Idea Board with cards in several lists
3. Decisions page with voter names and a recorded outcome
4. Team chat and Online list
5. Host Console log
